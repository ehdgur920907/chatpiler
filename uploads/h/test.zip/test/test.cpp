#include <iostream>
int main() {
  cout << "hello, world!";
  return 0;
}
